export const DURACION_ALERTA = 3000;

// Agregar al archivo existente
export const BOUNDS_CORRIENTES = {
  west: -60.9,
  east: -54.1,
  south: -31.1,
  north: -26.1,
};
